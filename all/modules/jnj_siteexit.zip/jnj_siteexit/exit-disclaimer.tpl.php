<?php
// $Id: exit-disclaimer-message.tpl.php,v 1.1 2007/11/04 14:29:09 goba Exp $

/**
 * @file exit-disclaimer-message.tpl.php
 *
 * Available variables:
 * - $message: Exit Disclaimer Message
 */
?>
<div class='extlink_content'><br />
	<?php print $message; ?>
</div>
<?php print $buttons; ?>