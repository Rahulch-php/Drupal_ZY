<h1 class="welcome_landing"><?php print t('Welcome to Renewed Hope PC'); ?></h1>
<div class="landing_selector">
<div class="selector_top">
<h3><?php print t('Please select your language'); ?></h3>
<?php print drupal_render($form['languages'])?>
<?php print drupal_render($form);?>
</div>
<div class="selector_bot">&nbsp;</div>
</div>
